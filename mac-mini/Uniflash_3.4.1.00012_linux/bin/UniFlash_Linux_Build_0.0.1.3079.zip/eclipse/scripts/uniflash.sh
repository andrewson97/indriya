#! /bin/sh
# This script executes UniFlash command line support

export CURPATH=$(dirname $(which $0))
export UNIFLASH_PATH=$CURPATH/uniflashv2/ccs_base/scripting/examples/uniflash/cmdLine/
$CURPATH/uniflashv2/ccs_base/scripting/bin/dss.sh $CURPATH/uniflashv2/ccs_base/scripting/examples/uniflash/cmdLine/uniFlash_main.js $@
